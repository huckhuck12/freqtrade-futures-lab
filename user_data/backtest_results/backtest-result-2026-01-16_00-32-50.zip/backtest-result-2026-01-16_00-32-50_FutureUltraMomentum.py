from freqtrade.strategy import IStrategy
from pandas import DataFrame
import pandas as pd
import talib.abstract as ta
from datetime import datetime


class FutureUltraMomentum(IStrategy):
    timeframe = '1m'
    max_open_trades = 1
    stake_amount = 100
    startup_candle_count = 100

    minimal_roi = {
        "0": 0.03,
        "60": 0.02,
        "180": 0.015,
        "360": 0.01
    }

    stoploss = -0.01
    trailing_stop = False

    order_types = {
        'entry': 'market',
        'exit': 'market',
        'stoploss': 'market',
        'stoploss_on_exchange': False
    }

    unfilledtimeout = {
        'entry': 30,
        'exit': 30,
        'unit': 'seconds'
    }

    leverage_config = {
        'BTC/USDT:USDT': 30.0,
        'ETH/USDT:USDT': 30.0,
        'SOL/USDT:USDT': 25.0,
        'XRP/USDT:USDT': 25.0,
        'DOGE/USDT:USDT': 25.0
    }

    def informative_pairs(self) -> list:
        return []

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        df = dataframe.copy()

        df['rsi'] = ta.RSI(df['close'].values, timeperiod=14)
        df['volume_sma'] = ta.SMA(df['volume'].values, timeperiod=20)
        df['high_5m'] = pd.Series(df['high']).rolling(5).max().values
        df['momentum'] = df['close'] / df['close'].shift(3) - 1

        return df

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 current_profit: float, min_stops: float, max_stops: float,
                 current_time_rows: DataFrame, **kwargs) -> float:
        return self.leverage_config.get(pair, 25.0)

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        df = dataframe.copy()
        df['enter_long'] = 0

        if len(df) < self.startup_candle_count:
            return df

        current_high = df['high'].iloc[-1]
        high_5m = df['high_5m'].iloc[-2] if len(df) > 1 else df['high'].iloc[-1]
        rsi = df['rsi'].iloc[-1]
        volume_ratio = df['volume'].iloc[-1] / df['volume_sma'].iloc[-1] if df['volume_sma'].iloc[-1] > 0 else 1

        momentum_ok = df['momentum'].iloc[-1] > 0.005

        strong_breakout = (
            current_high > high_5m and
            rsi > 80 and
            volume_ratio > 5.0 and
            momentum_ok
        )

        if strong_breakout:
            df.iloc[-1, df.columns.get_loc('enter_long')] = 1

        return df

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        df = dataframe.copy()
        df['exit'] = 0

        return df

    def custom_exit(self, pair: str, current_time: datetime, current_rate: float,
                    current_profit: float, **kwargs) -> bool:
        if current_profit > 0.03:
            return True
        if current_profit > 0.06:
            return True
        return False
