from freqtrade.strategy import IStrategy
from pandas import DataFrame
from datetime import datetime
from typing import List
import talib.abstract as ta


class FutureHighFreqV1(IStrategy):
    """
    High Frequency Trend Following Strategy V1 (Ultimate Edition)

    Combined strategies:
    1. RSI oversold + EMA golden cross
    2. Buy the dip (price < EMA50)
    3. Volume confirmation
    4. Trailing stop for profit capture
    """

    timeframe = '5m'
    max_open_trades = 10
    stake_amount = 0.10
    startup_candle_count = 300

    # Profit targets
    minimal_roi = {
        "0": 0.02,
        "20": 0.012,
        "60": 0.008,
        "120": 0.004,
        "240": 0
    }

    stoploss = -0.012
    trailing_stop = True
    trailing_stop_positive = 0.006
    trailing_stop_positive_offset = 0.01
    trailing_only_offset_is_reached = True

    order_types = {
        'entry': 'market',
        'exit': 'market',
        'stoploss': 'market',
        'stoploss_on_exchange': False
    }

    unfilledtimeout = {
        'entry': 5,
        'exit': 5,
        'unit': 'seconds'
    }

    # ===== Strategy Parameters =====
    fast_ema = 9
    slow_ema = 21
    ema50_period = 50
    rsi_period = 7
    rsi_buy = 45  # Oversold
    rsi_sell = 70
    adx_period = 14
    adx_threshold = 20

    # Buy the dip parameters
    use_buy_dip = True
    dip_lookback = 20
    dip_threshold = 0.03  # Within 3% of recent low

    # Volume filter
    use_volume_filter = True
    vol_ma_period = 20
    vol_multiplier = 0.8

    cooldown_period = 2

    def informative_pairs(self) -> List[tuple]:
        return []

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['fast_ema'] = ta.EMA(dataframe, timeperiod=self.fast_ema)
        dataframe['slow_ema'] = ta.EMA(dataframe, timeperiod=self.slow_ema)
        dataframe['ema50'] = ta.EMA(dataframe, timeperiod=self.ema50_period)
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=self.rsi_period)
        dataframe['adx'] = ta.ADX(dataframe, timeperiod=self.adx_period)

        dataframe['vol_ma'] = dataframe['volume'].rolling(window=self.vol_ma_period).mean()
        dataframe['vol_ratio'] = dataframe['volume'] / dataframe['vol_ma']

        # Buy the dip: distance from recent low
        dataframe['recent_low'] = dataframe['low'].rolling(window=self.dip_lookback).min()
        dataframe['dip_distance'] = (dataframe['close'] - dataframe['recent_low']) / dataframe['recent_low']

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # EMA golden cross
        golden_cross = (
            (dataframe['fast_ema'] > dataframe['slow_ema']) &
            (dataframe['fast_ema'].shift(1) <= dataframe['slow_ema'].shift(1))
        )

        # RSI oversold
        rsi_oversold = dataframe['rsi'] < self.rsi_buy

        # Buy the dip: price near recent low
        if self.use_buy_dip:
            buy_dip = dataframe['dip_distance'] < self.dip_threshold
        else:
            buy_dip = True

        # Price above EMA50 (uptrend)
        uptrend = dataframe['close'] > dataframe['ema50']

        # Volume confirmation
        if self.use_volume_filter:
            volume_ok = dataframe['vol_ratio'] > self.vol_multiplier
        else:
            volume_ok = True

        conditions = golden_cross & rsi_oversold & buy_dip & uptrend & volume_ok & (dataframe['volume'] > 0)

        dataframe.loc[conditions, 'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # Death cross
        death_cross = (
            (dataframe['fast_ema'] < dataframe['slow_ema']) &
            (dataframe['fast_ema'].shift(1) >= dataframe['slow_ema'].shift(1))
        )

        # RSI overbought
        rsi_overbought = dataframe['rsi'] > self.rsi_sell

        # Trend reversal (price below EMA50)
        trend_reversal = dataframe['close'] < dataframe['ema50']

        conditions = (death_cross | rsi_overbought | trend_reversal) & (dataframe['volume'] > 0)

        dataframe.loc[conditions, 'exit'] = 1
        return dataframe
