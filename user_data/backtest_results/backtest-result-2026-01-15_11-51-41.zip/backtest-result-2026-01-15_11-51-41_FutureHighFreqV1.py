from freqtrade.strategy import IStrategy
from pandas import DataFrame
from datetime import datetime
from typing import List
import talib.abstract as ta


class FutureHighFreqV1(IStrategy):
    """
    High Frequency Breakout Strategy V1

    Strategy:
    - Buy when price breaks above recent high
    - Sell when price breaks below recent low
    - Trailing stop for profit capture
    - Simple and effective in bull markets
    """

    timeframe = '5m'
    max_open_trades = 10
    stake_amount = 0.10
    startup_candle_count = 300

    # Quick profit targets
    minimal_roi = {
        "0": 0.015,
        "15": 0.01,
        "45": 0.005,
        "90": 0.002,
        "180": 0
    }

    stoploss = -0.01
    trailing_stop = True
    trailing_stop_positive = 0.005
    trailing_stop_positive_offset = 0.008
    trailing_only_offset_is_reached = True

    order_types = {
        'entry': 'market',
        'exit': 'market',
        'stoploss': 'market',
        'stoploss_on_exchange': False
    }

    unfilledtimeout = {
        'entry': 5,
        'exit': 5,
        'unit': 'seconds'
    }

    # ===== Strategy Parameters =====
    # Breakout parameters
    lookback_high = 20  # Lookback period for high
    lookback_low = 20    # Lookback period for low

    # RSI filter (optional)
    rsi_period = 7
    rsi_buy = 65
    use_rsi_filter = True

    cooldown_period = 2

    def informative_pairs(self) -> List[tuple]:
        return []

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # Rolling high/low
        dataframe['rolling_high'] = dataframe['high'].rolling(window=self.lookback_high).max()
        dataframe['rolling_low'] = dataframe['low'].rolling(window=self.lookback_low).min()

        # Price position (0 = at low, 1 = at high)
        dataframe['price_position'] = (
            (dataframe['close'] - dataframe['rolling_low']) /
            (dataframe['rolling_high'] - dataframe['rolling_low'] + 0.0001)
        )

        # RSI
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=self.rsi_period)

        # ATR for volatility
        dataframe['atr'] = ta.ATR(dataframe, timeperiod=14)
        dataframe['atr_pct'] = dataframe['atr'] / dataframe['close']

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # Breakout: price breaks above recent high
        breakout = (
            (dataframe['close'] > dataframe['rolling_high'].shift(1)) &
            (dataframe['close'].shift(1) <= dataframe['rolling_high'].shift(1))
        )

        # Strong momentum: price near high
        near_high = dataframe['price_position'] > 0.8

        conditions = breakout & near_high & (dataframe['volume'] > 0)

        if self.use_rsi_filter:
            conditions = conditions & (dataframe['rsi'] < self.rsi_buy)

        dataframe.loc[conditions, 'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # Breakdown: price breaks below recent low
        breakdown = (
            (dataframe['close'] < dataframe['rolling_low'].shift(1)) &
            (dataframe['close'].shift(1) >= dataframe['rolling_low'].shift(1))
        )

        # Or price reverses from high
        reversal = dataframe['price_position'] < 0.2

        conditions = (breakdown | reversal) & (dataframe['volume'] > 0)

        dataframe.loc[conditions, 'exit'] = 1
        return dataframe
