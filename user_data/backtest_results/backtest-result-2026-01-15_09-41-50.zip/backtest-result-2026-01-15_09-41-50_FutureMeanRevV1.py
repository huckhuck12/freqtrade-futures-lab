from freqtrade.strategy import IStrategy
from pandas import DataFrame
from typing import Dict, List
import talib.abstract as ta


class FutureMeanRevV1(IStrategy):
    """
    Futures Mean Reversion Strategy V1

    Strategy logic:
    - Uses Bollinger Bands and RSI for mean reversion trading
    - Buy when price touches lower Bollinger Band and RSI < 35
    - Sell when price touches upper Bollinger Band or RSI > 75
    """

    minimal_roi = {
        "0": 0.08
    }

    stoploss = -0.05

    trailing_stop = False
    trailing_stop_positive = 0.02
    trailing_stop_positive_offset = 0.03
    trailing_only_offset_is_reached = False

    order_types = {
        'entry': 'limit',
        'exit': 'limit',
        'stoploss': 'market',
        'stoploss_on_exchange': False
    }

    timeframe = '5m'

    stake_amount = 0.01

    startup_candle_count = 300

    unfilledtimeout = {
        'entry': 10,
        'exit': 10,
        'exit_timeout_count': 0,
        'unit': 'seconds'
    }

    # Bollinger Bands parameters
    bb_period = 20
    bb_std = 2.0
    # RSI period
    rsi_period = 14
    # RSI oversold threshold
    rsi_oversold = 35
    # RSI overbought threshold
    rsi_overbought = 75

    def informative_pairs(self) -> List[tuple]:
        """
        Define informative pairs.
        """
        return []

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Calculate indicators for the strategy.
        """
        # Calculate Bollinger Bands
        bb = ta.BBANDS(dataframe, timeperiod=self.bb_period, nbdevup=self.bb_std, nbdevdn=self.bb_std)
        dataframe['bb_lower'] = bb['lowerband']
        dataframe['bb_middle'] = bb['middleband']
        dataframe['bb_upper'] = bb['upperband']

        # Calculate RSI
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=self.rsi_period)

        # Calculate percentage position between bands
        dataframe['bb_position'] = (dataframe['close'] - dataframe['bb_lower']) / (dataframe['bb_upper'] - dataframe['bb_lower'])

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Entry signal logic.
        """
        dataframe.loc[
            (dataframe['bb_position'] < 0.05) &
            (dataframe['rsi'] < self.rsi_oversold) &
            (dataframe['volume'] > 0),
            'enter_long'
        ] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Exit signal logic.
        """
        dataframe.loc[
            (
                (dataframe['bb_position'] > 0.95) |
                (dataframe['rsi'] > self.rsi_overbought)
            ) &
            (dataframe['volume'] > 0),
            'exit'
        ] = 1

        return dataframe