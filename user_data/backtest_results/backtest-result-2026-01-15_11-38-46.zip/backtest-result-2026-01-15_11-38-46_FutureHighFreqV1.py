from freqtrade.strategy import IStrategy
from pandas import DataFrame
from datetime import datetime
from typing import List
import talib.abstract as ta


class FutureHighFreqV1(IStrategy):
    """
    High Frequency Trend Following Strategy V1 (100% ROI Target Edition)

    Strategy Logic:
    - Long only (no shorting in bull market)
    - Buy the dip strategy
    - Aggressive trailing stop for maximum profit capture
    - Strong trend confirmation

    Timeframe: 5m
    Pairs: 10 high-volatility futures pairs
    """

    timeframe = '5m'
    max_open_trades = 10
    stake_amount = 0.10
    startup_candle_count = 300

    # Aggressive profit targets
    minimal_roi = {
        "0": 0.03,      # 3% quick profit
        "60": 0.02,     # 2% in 1 hour
        "180": 0.015,   # 1.5% in 3 hours
        "360": 0.01,    # 1% in 6 hours
        "720": 0.005,   # 0.5% in 12 hours
        "1440": 0       # Hold longer
    }

    stoploss = -0.015
    trailing_stop = True
    trailing_stop_positive = 0.01  # 1% trail start
    trailing_stop_positive_offset = 0.015  # 1.5% offset
    trailing_only_offset_is_reached = True

    order_types = {
        'entry': 'market',
        'exit': 'market',
        'stoploss': 'market',
        'stoploss_on_exchange': False
    }

    unfilledtimeout = {
        'entry': 5,
        'exit': 5,
        'unit': 'seconds'
    }

    # ===== Core Strategy Parameters =====
    fast_ema = 9
    slow_ema = 21
    ema50_period = 50

    # RSI parameters - Buy the dip
    rsi_period = 7
    rsi_buy_threshold = 45  # Buy when oversold
    rsi_sell_threshold = 85  # Only sell when extremely overbought
    use_rsi_filter = True

    # ADX parameters - Strong trend
    adx_period = 14
    adx_threshold = 30
    use_adx_filter = True

    # ATR parameters
    atr_period = 14
    atr_max_pct = 0.06
    use_atr_filter = True

    # Buy the dip filter - Price must be near recent low
    use_buy_dip_filter = True
    dip_lookback = 20
    dip_threshold = 0.02  # Within 2% of recent low

    # Strong trend filter
    use_strong_trend_filter = True

    # Volume filter
    vol_ma_period = 20
    use_vol_filter = True
    vol_multiplier = 0.7

    cooldown_period = 3

    def informative_pairs(self) -> List[tuple]:
        return []

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['fast_ema'] = ta.EMA(dataframe, timeperiod=self.fast_ema)
        dataframe['slow_ema'] = ta.EMA(dataframe, timeperiod=self.slow_ema)
        dataframe['ema50'] = ta.EMA(dataframe, timeperiod=self.ema50_period)

        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=self.rsi_period)
        dataframe['adx'] = ta.ADX(dataframe, timeperiod=self.adx_period)
        dataframe['atr'] = ta.ATR(dataframe, timeperiod=self.atr_period)

        dataframe['vol_ma'] = dataframe['volume'].rolling(window=self.vol_ma_period).mean()
        dataframe['vol_ratio'] = dataframe['volume'] / dataframe['vol_ma']

        dataframe['atr_pct'] = dataframe['atr'] / dataframe['close']

        # Buy the dip: Calculate distance from recent low
        dataframe['recent_low'] = dataframe['low'].rolling(window=self.dip_lookback).min()
        dataframe['dip_distance'] = (dataframe['close'] - dataframe['recent_low']) / dataframe['recent_low']

        # EMA trend direction
        dataframe['ema_trend'] = (dataframe['fast_ema'] > dataframe['ema50']).astype(int)

        return dataframe

    def custom_stoploss(self, dataframe: DataFrame, pair: str, trade_id: int,
                        current_profit: float, min_rate: float, max_rate: float,
                        current_entry_rate: float, current_exit_rate: float,
                        current_time: datetime) -> float:
        """
        Dynamic stop loss - tighter when in profit.
        """
        if current_profit > 0.05:
            return -0.005  # Tight stop when up 5%
        elif current_profit > 0.03:
            return -0.008
        elif current_profit > 0.02:
            return -0.01
        else:
            return self.stoploss

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Long only entry - Buy the dip with trend confirmation.
        """
        # Strong EMA trend: Fast EMA > Slow EMA > EMA50
        strong_trend = (
            (dataframe['fast_ema'] > dataframe['slow_ema']) &
            (dataframe['slow_ema'] > dataframe['ema50'])
        )

        # EMA crossover signal
        ema_crossover = (
            (dataframe['fast_ema'] > dataframe['slow_ema']) &
            (dataframe['fast_ema'].shift(1) <= dataframe['slow_ema'].shift(1))
        )

        # Buy the dip: RSI oversold and price near recent low
        buy_dip = (
            (dataframe['rsi'] < self.rsi_buy_threshold) &
            (dataframe['dip_distance'] < self.dip_threshold)
        )

        conditions = strong_trend & ema_crossover & buy_dip & (dataframe['volume'] > 0)

        if self.use_adx_filter:
            conditions = conditions & (dataframe['adx'] > self.adx_threshold)

        if self.use_atr_filter:
            conditions = conditions & (dataframe['atr_pct'] < self.atr_max_pct)

        if self.use_vol_filter:
            conditions = conditions & (dataframe['vol_ratio'] > self.vol_multiplier)

        dataframe.loc[conditions, 'enter_long'] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Exit when trend reverses or RSI overbought.
        """
        # EMA death cross
        ema_crossover = (
            (dataframe['fast_ema'] < dataframe['slow_ema']) &
            (dataframe['fast_ema'].shift(1) >= dataframe['slow_ema'].shift(1))
        )

        # Or RSI overbought
        rsi_overbought = dataframe['rsi'] > self.rsi_sell_threshold

        # Or strong trend broken
        trend_broken = dataframe['fast_ema'] < dataframe['ema50']

        conditions = (ema_crossover | rsi_overbought | trend_broken) & (dataframe['volume'] > 0)

        dataframe.loc[conditions, 'exit'] = 1

        return dataframe
