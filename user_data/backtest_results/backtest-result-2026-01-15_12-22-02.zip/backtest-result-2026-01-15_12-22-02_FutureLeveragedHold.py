from freqtrade.strategy import IStrategy
from pandas import DataFrame
import pandas as pd
from datetime import datetime


class FutureLeveragedHold(IStrategy):
    timeframe = '5m'
    max_open_trades = 3
    stake_amount = 0.30
    startup_candle_count = 50

    minimal_roi = {
        "0": 0.02,
        "120": 0.015,
        "240": 0.01,
        "480": 0.005
    }

    stoploss = -0.03
    trailing_stop = True
    trailing_stop_positive = 0.015
    trailing_stop_positive_offset = 0.02
    trailing_only_offset_is_reached = True

    order_types = {
        'entry': 'market',
        'exit': 'market',
        'stoploss': 'market',
        'stoploss_on_exchange': False
    }

    unfilledtimeout = {
        'entry': 30,
        'exit': 30,
        'unit': 'seconds'
    }

    leverage_config = {
        'BTC/USDT:USDT': 5.0,
        'ETH/USDT:USDT': 5.0,
        'SOL/USDT:USDT': 5.0,
        'XRP/USDT:USDT': 3.0,
        'DOGE/USDT:USDT': 3.0,
        'LTC/USDT:USDT': 3.0,
        'LINK/USDT:USDT': 3.0,
        'UNI/USDT:USDT': 3.0,
        'ARB/USDT:USDT': 3.0,
        'OP/USDT:USDT': 3.0
    }

    cooldown_period = 12

    def informative_pairs(self) -> list:
        return []

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        return dataframe

    def custom_stoploss(self, pair: str, current_time: datetime, current_rate: float,
                        current_profit: float, min_stops: float, max_stops: float,
                        current_time_rows: DataFrame, **kwargs) -> float:
        leverage = self.leverage_config.get(pair, 3.0)
        return -0.03 / leverage

    def custom_entry_price(self, pair: str, current_time: datetime, current_rate: float,
                           proposed_rate: float, current_order: dict, side: str,
                           **kwargs) -> float:
        return proposed_rate

    def custom_exit_price(self, pair: str, current_time: datetime, current_rate: float,
                          proposed_rate: float, current_order: dict, side: str,
                          **kwargs) -> float:
        return proposed_rate

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 current_profit: float, min_stops: float, max_stops: float,
                 current_time_rows: DataFrame, **kwargs) -> float:
        leverage = self.leverage_config.get(pair, 3.0)
        return min(leverage, 5.0)

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        df = dataframe.copy()
        df['enter_long'] = 0

        if len(df) < self.startup_candle_count:
            return df

        try:
            df['ema_9'] = pd.Series(df['close']).ewm(span=9, adjust=False).mean()
            df['ema_21'] = pd.Series(df['close']).ewm(span=21, adjust=False).mean()
            df['ema_50'] = pd.Series(df['close']).ewm(span=50, adjust=False).mean()

            uptrend = (
                (df['ema_9'].iloc[-1] > df['ema_21'].iloc[-1]) &
                (df['ema_21'].iloc[-1] > df['ema_50'].iloc[-1])
            )

            df.loc[uptrend, 'enter_long'] = 1

        except Exception:
            pass

        return df

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        df = dataframe.copy()
        df['exit'] = 0

        try:
            df['ema_9'] = pd.Series(df['close']).ewm(span=9, adjust=False).mean()
            df['ema_21'] = pd.Series(df['close']).ewm(span=21, adjust=False).mean()

            trend_reversal = df['ema_9'].iloc[-1] < df['ema_21'].iloc[-1]

            if trend_reversal:
                df.loc[True, 'exit'] = 1

        except Exception:
            pass

        return df
