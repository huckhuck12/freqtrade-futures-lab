from freqtrade.strategy import IStrategy
from pandas import DataFrame
import pandas as pd
import talib.abstract as ta
from datetime import datetime


class FutureUltraMomentum(IStrategy):
    timeframe = '1m'
    max_open_trades = 1
    stake_amount = 100
    startup_candle_count = 100

    minimal_roi = {
        "0": 0.03,
        "60": 0.02,
        "180": 0.015,
        "360": 0.01
    }

    stoploss = -0.01
    trailing_stop = False

    order_types = {
        'entry': 'market',
        'exit': 'market',
        'stoploss': 'market',
        'stoploss_on_exchange': False
    }

    unfilledtimeout = {
        'entry': 30,
        'exit': 30,
        'unit': 'seconds'
    }

    leverage_config = {
        'BTC/USDT:USDT': 30.0,
        'ETH/USDT:USDT': 30.0,
        'SOL/USDT:USDT': 25.0,
        'XRP/USDT:USDT': 25.0,
        'DOGE/USDT:USDT': 25.0
    }

    def informative_pairs(self) -> list:
        return []

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        df = dataframe.copy()

        # Core indicators
        df['rsi'] = ta.RSI(df['close'].values, timeperiod=14)
        df['rsi_6'] = ta.RSI(df['close'].values, timeperiod=6)
        df['volume_sma'] = ta.SMA(df['volume'].values, timeperiod=20)

        # Trend indicators
        df['ema_12'] = ta.EMA(df['close'].values, timeperiod=12)
        df['ema_26'] = ta.EMA(df['close'].values, timeperiod=26)
        df['ema_trend'] = (df['ema_12'] - df['ema_26']) / df['close']

        # Momentum indicators
        df['momentum'] = df['close'] / df['close'].shift(3) - 1
        df['momentum_6'] = df['close'] / df['close'].shift(6) - 1

        # Volatility
        df['atr'] = ta.ATR(df['high'].values, df['low'].values, df['close'].values, timeperiod=14)
        df['atr_percent'] = df['atr'] / df['close']

        # Volume indicators
        df['volume_ratio'] = df['volume'] / df['volume_sma']
        df['volume_trend'] = df['volume'] / df['volume'].shift(3)

        # Price action
        df['high_5m'] = pd.Series(df['high']).rolling(5).max().values
        df['close_change'] = df['close'].pct_change(3)

        return df

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 current_profit: float, min_stops: float, max_stops: float,
                 current_time_rows: DataFrame, **kwargs) -> float:
        return self.leverage_config.get(pair, 25.0)

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        df = dataframe.copy()
        df['enter_long'] = 0

        if len(df) < self.startup_candle_count:
            return df

        # Stricter entry conditions for higher win rate
        trend_up = df['ema_trend'] > 0.005  # EMA golden cross trend
        rsi_good = (df['rsi'] > 60) & (df['rsi'] < 75)  # RSI in good range
        rsi_rising = df['rsi'] > df['rsi'].shift(3)  # RSI trending up
        momentum_strong = (df['momentum'] > 0.008) & (df['momentum_6'] > 0.015)  # Strong momentum
        volume_surge = (df['volume_ratio'] > 1.5) & (df['volume_trend'] > 1.2)  # Volume confirmation
        volatility_ok = df['atr_percent'] < 0.03  # Not too volatile
        price_action = df['close_change'] > 0.005  # Recent price up

        # All conditions must be met for entry
        perfect_setup = (
            trend_up &
            rsi_good &
            rsi_rising &
            momentum_strong &
            volume_surge &
            volatility_ok &
            price_action
        )

        df.loc[perfect_setup, 'enter_long'] = 1

        return df

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        df = dataframe.copy()
        df['exit'] = 0

        # Trend reversal exits
        trend_down = df['ema_trend'] < -0.005
        rsi_overbought = df['rsi'] > 80
        momentum_weak = df['momentum'] < -0.005

        df.loc[trend_down | rsi_overbought | momentum_weak, 'exit'] = 1

        return df

    def custom_exit(self, pair: str, current_time: datetime, current_rate: float,
                    current_profit: float, **kwargs) -> bool:
        # Partial profit taking for better risk management
        if current_profit > 0.025:  # Take 50% profit at 2.5%
            return True
        if current_profit > 0.05:   # Take remaining at 5%
            return True
        if current_profit < -0.015: # Stop loss at -1.5%
            return True
        return False
