from freqtrade.strategy import IStrategy
from pandas import DataFrame
import pandas as pd
import talib.abstract as ta
from datetime import datetime


class NineSecondSniper(IStrategy):
    """
    9秒狙击手策略 - 高频动量狙击

    核心理念：
    - 9秒内快速识别并狙击动量机会
    - 超短线持仓，快速进出
    - 高胜率，高风险，高收益

    策略特点：
    - 1秒时间框架（模拟9秒逻辑）
    - 多重动量确认
    - 严格的时间窗口
    - 极致风险控制
    """

    timeframe = '1m'  # 1分钟框架，模拟9秒逻辑
    max_open_trades = 1  # 每次只持有一笔交易
    stake_amount = 100
    startup_candle_count = 50

    minimal_roi = {
        "0": 0.005,    # 5秒内0.5%利润
        "9": 0.002,    # 9秒内0.2%利润
        "30": 0.001,   # 30秒内0.1%利润
    }

    stoploss = -0.008  # 0.8%止损，更保守
    trailing_stop = True
    trailing_stop_positive = 0.003  # 0.3%追踪止损
    trailing_stop_positive_offset = 0.005  # 0.5%偏移

    order_types = {
        'entry': 'market',
        'exit': 'market',
        'stoploss': 'market',
        'stoploss_on_exchange': False
    }

    unfilledtimeout = {
        'entry': 1,  # 1秒超时
        'exit': 1,
        'unit': 'seconds'
    }

    leverage_config = {
        'BTC/USDT:USDT': 5.0,   # 大幅降低杠杆
        'ETH/USDT:USDT': 4.0,
        'SOL/USDT:USDT': 3.0,
        'XRP/USDT:USDT': 2.0,
        'DOGE/USDT:USDT': 2.0
    }

    def informative_pairs(self) -> list:
        return []

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        df = dataframe.copy()

        # 模拟9秒逻辑：在1分钟数据中使用短期动量
        # 9秒 ≈ 0.15分钟，我们使用1-2根K线来模拟

        # 核心动量指标（使用1-2根K线模拟9秒）
        df['momentum_1'] = df['close'] / df['close'].shift(1) - 1  # 1分钟动量（模拟3秒）
        df['momentum_2'] = df['close'] / df['close'].shift(2) - 1  # 2分钟动量（模拟6秒）
        df['momentum_3'] = df['close'] / df['close'].shift(3) - 1  # 3分钟动量（模拟9秒）

        # 动量加速
        df['accel_1'] = df['momentum_1'] - df['momentum_1'].shift(1)
        df['accel_2'] = df['momentum_2'] - df['momentum_2'].shift(1)

        # 成交量确认
        df['volume_sma'] = ta.SMA(df['volume'].values, timeperiod=10)
        df['volume_ratio'] = df['volume'] / df['volume_sma']

        # 波动率过滤
        df['returns'] = df['close'].pct_change()
        df['volatility'] = df['returns'].rolling(10).std()

        # 价格变化（模拟9秒窗口）
        df['price_change_1'] = df['close'].pct_change(1)
        df['price_change_2'] = df['close'].pct_change(2)

        # 9秒窗口内的动量强度
        df['momentum_strength'] = (df['momentum_1'] + df['momentum_2'] + df['momentum_3']) / 3

        return df

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 current_profit: float, min_stops: float, max_stops: float,
                 current_time_rows: DataFrame, **kwargs) -> float:
        base_leverage = self.leverage_config.get(pair, 10.0)

        # 根据波动率调整杠杆
        if not current_time_rows.empty and 'volatility' in current_time_rows.columns:
            volatility = current_time_rows['volatility'].iloc[-1]
            if volatility > 0.001:  # 高波动
                base_leverage *= 0.8
            elif volatility < 0.0005:  # 低波动
                base_leverage *= 1.2

        return min(base_leverage, 25.0)  # 最高25x

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        df = dataframe.copy()
        df['enter_long'] = 0

        if len(df) < self.startup_candle_count:
            return df

        # 优化后的9秒狙击手核心逻辑（更严格的质量控制）
        sniper_conditions = (
            # 强动量爆发（更严格的阈值）
            (df['momentum_1'] > 0.002) &  # 1分钟强正动量
            (df['momentum_2'] > 0.004) &  # 2分钟强正动量
            (df['momentum_3'] > 0.006) &  # 3分钟强正动量
            # 动量加速确认
            (df['accel_1'] > 0.0005) &  # 动量加速中
            (df['accel_2'] > 0.0005) &
            # 价格强势上涨
            (df['price_change_1'] > 0.001) &  # 1分钟内显著上涨
            (df['price_change_2'] > 0.002) &   # 2分钟内强势上涨
            # 成交量爆发
            (df['volume_ratio'] > 2.5) &  # 成交量大幅放大
            # 波动率适中
            (df['volatility'] > 0.0005) & (df['volatility'] < 0.002) &  # 适度波动
            # 动量强度极强
            (df['momentum_strength'] > 0.004)
        )

        df.loc[sniper_conditions, 'enter_long'] = 1

        return df

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        df = dataframe.copy()
        df['exit'] = 0

        # 狙击手退出逻辑（1分钟数据模拟）
        exit_conditions = (
            # 动量衰减
            (df['momentum_1'] < df['momentum_1'].shift(1)) |  # 动量减弱
            (df['accel_1'] < 0) |  # 动量开始减速
            # 价格回调
            (df['price_change_1'] < -0.0008) |  # 价格开始回落
            # 动量强度下降
            (df['momentum_strength'] < df['momentum_strength'].shift(1))  # 整体动量减弱
        )

        df.loc[exit_conditions, 'exit'] = 1

        return df

    def custom_exit(self, pair: str, current_time: datetime, current_rate: float,
                    current_profit: float, **kwargs) -> bool:
        # 优化后的利润保护（更保守）
        if current_profit > 0.012:  # 1.2%利润锁定部分收益
            return True
        if current_profit > 0.025:  # 2.5%利润全部退出
            return True
        if current_profit < -0.01:  # 1%亏损立即止损
            return True
        return False
